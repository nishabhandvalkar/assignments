import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-comp',
  templateUrl: './new-comp.component.html',
  styleUrls: ['./new-comp.component.css']
})
export class NewCompComponent {

 public name:string = "Marvellous";
 public str:string = "Infosystems";
 public upper:string = '';
 public lower:string = '';
 public con:string = '';

 public getUppercase()
 {
  this.upper = this.name.toUpperCase();
 }
 public getLowercase()
 {
   this.lower = this.name.toLowerCase();
 }
 public concat()
 {
   this.con = this.name.concat(this.str);
 }

}
