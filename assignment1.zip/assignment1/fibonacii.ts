/*
write a typescript program which contains one function named as fibonacii that function accepts one 
number from user and print fibonacii series till that number.
*/

function fibonacii(num : number)
{
    var num1 : number = 0;
    var num2 : number = 1;
    for(var i = 0; i<num; i++)
    {
        var sum = num1 + num2;
        num1 = num2;
        num2 = sum;
        console.log(sum);
    }
}

fibonacii(8);