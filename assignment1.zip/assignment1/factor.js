/*
write a typescript program which contains one function named as DisplayFactors. that function should accept
one number and display factors of that number.
input: 20
output: 1 2 4 5 10

*/
function DisplayFactors(num) {
    for (var i = 1; i < num; i++) {
        if ((num % i) == 0) {
            console.log(i);
        }
    }
}
DisplayFactors(20);
