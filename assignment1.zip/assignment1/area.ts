/*
write a typescript program which contains one function named as area. that function should calculate area 
of circle. accept value of radius from user and return its area.default value of PI should be 3.14. 
if it is not provided.
input : 5
output : area of circle is 78.5
*/

function main_fun(): void
{
    //var circle_area = area(undefined, 5);
    var circle_area = area(3.14,5);
    console.log("Area of circle is " + circle_area);
}

function area(PI = 3.14, radius : number): number
{
    var ans = PI * radius * radius;
    return ans;
}
main_fun();