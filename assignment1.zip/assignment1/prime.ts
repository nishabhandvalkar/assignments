/*
write a typescript program which contains one function named as ChkPrime. The function should accept 
one number and it should return true if the given number is prime otherwise return false.
*/

function isPrime(a1 : number): void
{
    var ans = ChkPrime(a1);
    if(ans === true)
    {
        console.log(a1 + " is a prime number");
    }
    else
    {
        console.log(a1 + " is not a prime number");
    }
}


function ChkPrime(num: number): boolean
{
  for(var i = 2; i <= num; i++)
  {
      if((num % i) == 0)
      {
          return false;
      }
      else
      {
        return true;
      }
  }
}

isPrime(11);