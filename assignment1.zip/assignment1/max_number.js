/*
write a typescript program which contains one function named as maximum. That function accepts three
parameters and it should return largest value from three input parameters.
input: 23, 89, 6
output: Maximum number is 89
*/
function main() {
    var ans = maximum(23, 89, 6);
    console.log("Maximum number is " + ans);
}
function maximum(num1, num2, num3) {
    var max = 0;
    if (num1 > num2) {
        max = num1;
    }
    else if (num2 > num1) {
        max = num2;
    }
    if (num3 > max) {
        return num3;
    }
    else {
        return max;
    }
}
main();
