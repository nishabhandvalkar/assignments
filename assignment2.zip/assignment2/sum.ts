/*
write a typescript program which contains one function named as summation.that function accepts array
of numbers and returns the summation of each number from array.
input: 23 6 7 4 5 7
output: addition is 52
*/

function ArrSum():void
{
    var ans = sum([23,6,7,4,5,7]);
    console.log("Addition is "+ ans);
}
function sum(arr:number[]):number
{
    var sum:number = 0;
    var len:number = arr.length;
    for(var i = 0; i <= (len - 1); i++)
    {
        sum = sum + arr[i];
    }
    return sum;
}
ArrSum();