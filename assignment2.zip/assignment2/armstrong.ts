/*
 write a typescript program which contains one arrow function named as ChkArmstrong. that function accepts 
 one number and check wheather that number is armstrong number or not
 Input: 153
 output: It is Armstrong number
*/

function checkArmstrong(num:number):void
{
    let sum:number = 0;
    let temp:number = num;
    while(temp>0){
        var reminder = temp % 10;
        sum += reminder*reminder*reminder;
        temp = Math.floor(temp/10);
    }
   if(sum == num){
       console.log(num + " is Armstrong number");
   }else{
    console.log(num + " is Not Armstrong number")
   }
}
    checkArmstrong(154);