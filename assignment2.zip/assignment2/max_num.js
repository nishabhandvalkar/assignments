/*
write a typescript program which contains one function named as Maximum, that function accepts array
of numbers and returns the largest number from array
*/
function largestNum() {
    var maxnum = Maximum([23, 89, 6, 29, 56, 45, 77, 32]);
    console.log("Largest number is " + maxnum);
}
function Maximum(num) {
    var a1 = 0;
    for (var i = 0; i < num.length; i++) {
        if (num[i] > num[i + 1]) {
            a1 = num[i];
            num[i] = num[i + 1];
            num[i + 1] = a1;
        }
    }
    return num[i - 1];
}
largestNum();
