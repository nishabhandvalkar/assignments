/*
write a typescript program which contains one function named as maximum, that function accepts 
array of numbers and returns the second largest number from array.
input:  23 89 6 29 56 45 77 32
output: Second maximum number is 77
*/

function displayMax():void
{
    var second_max = SecondMax([23,89,6,29,56,45,77,32]);
    console.log("Second maximum number is "+ second_max);
}

function SecondMax(arr:number[]):number
{
    var len:number = arr.length;
    arr.sort();
    return arr[len-2];
}

displayMax();

// function SecondMax(arr:number[]):number
// {
//     var len:number = arr.length;

//     for(var i=0; i<len;i++){
//         for(var j=i+1; j<len; j++){
//             if(arr[i] > arr[j]){
//                 var num = arr[i];
//                 arr[i] = arr[j];
//                 arr[j] = num;
//             }
//         }
//     }
//     //console.log(arr);
//     return arr[len-2];
// }

