/*
write a typescript program which contains one function named as ChkString. That function accepts 
one string and check weather that string contains "Marvellous" word or not.
input: "Pune kothrud Marvellous Infosystems";
output: "String contains Marvellous in it."
*/

function ChkString(str:string):void
{
    var mainstring: string = "Pune kothrud Marvellous Infosystems";
    var substring:string = str;
    if(mainstring.indexOf(`${substring}`) > 0){
        console.log("String contains " +substring+ " in it");
    }else{
        console.log("string not contains "+substring+" in it");
    }

}
ChkString("Marvellous");