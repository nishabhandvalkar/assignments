/*
create one class named circleX. inherit class circle and create one circumeference method in circleX
 and create object and fetch methods.
*/

class Circle1
{
    radius:number;
    PI:number;
    constructor(rad:number)
    {
        this.radius = rad;
        this.PI = 3.14;
    }
    Area()
    {
        var area:number = 0;
        area = this.PI * this.radius * this.radius;
        return area;
    }
}

class CircleX extends Circle
{
    constructor(radius:number)
    {
        super(radius); 
        this.PI = 3.14;  
    }
    Circumference()
    {
        var circumference:number = 0;
        circumference = 2 * this.PI * this.radius;
        return circumference;
    }
}

var obj4 = new CircleX(4);
var ans:number = 0;
ans = obj4.Area();
console.log("Area of circle is "+ ans)


var obj5 = new CircleX(4);
var circumference = obj5.Circumference();
console.log("Circumference of Circle is : "+ circumference);

var obj6 = new CircleX(5);
var ans:number = 0;
ans = obj6.Area();
console.log("Area of circle is "+ ans)


var obj7 = new CircleX(5);
var circumference = obj7.Circumference();
console.log("Circumference of Circle is : "+ Math.floor(circumference));