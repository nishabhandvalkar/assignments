var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Circle = /** @class */ (function () {
    function Circle(rad) {
        this.radius = rad;
        this.PI = 3.14;
    }
    Circle.prototype.Area = function () {
        var area = 0;
        area = this.PI * this.radius * this.radius;
        return area;
    };
    return Circle;
}());
var CircleX = /** @class */ (function (_super) {
    __extends(CircleX, _super);
    function CircleX(radius) {
        var _this = _super.call(this, radius) || this;
        _this.PI = 3.14;
        return _this;
    }
    CircleX.prototype.Circumference = function () {
        var circumference = 0;
        circumference = 2 * this.PI * this.radius;
        return circumference;
    };
    return CircleX;
}(Circle));
var obj4 = new CircleX(4);
var ans = 0;
ans = obj4.Area();
console.log("Area of circle is " + ans);
var obj5 = new CircleX(4);
var circumference = obj5.Circumference();
console.log("Circumference of Circle is : " + circumference);
var obj6 = new CircleX(5);
var ans = 0;
ans = obj6.Area();
console.log("Area of circle is " + ans);
var obj7 = new CircleX(5);
var circumference = obj7.Circumference();
console.log("Circumference of Circle is : " + Math.floor(circumference));
