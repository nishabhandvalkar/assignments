/*
create one class named circle. it will contain radius and PI.create one parameterized constructor which 
accept one parameter. write on Area method. and create object and fetch method.
*/
class Circle
{
    radius:number;
    PI:number = 3.14;
    constructor(rad:number)
    {
        this.radius = rad;
    }
    Area()
    {
        var area:number = 0;
        area = this.PI * this.radius * this.radius;
        return area;
    }
}
var obj = new Circle(5);
var ans:number = 0;
ans = obj.Area();
console.log("Area of first circle is: " +ans);

var obj3 = new Circle(8);
var ans:number = 0;
ans = obj3.Area();
console.log("Area of second circle is: " +ans);