/*
create typescript application which contains one class named Arithmetic.
arithmetic class contains three characteristics number1 and number2.
create one parameterized constructor. write 4 methods addition, substraction, multiplication and division.

*/

class Arithmetic
{
     no1 : number;
     no2 : number;

    constructor(a:number, b:number)
    {
        this.no1 = a;
        this.no2 = b;

    }

    Addition()
    {
        var res : number = 0;
        res = this.no1 + this.no2;
        return res;
    }

    Substraction()
    {
        var res : number = 0;
        res = this.no1 - this.no2;
        return res;
    }

    Multiplication()
    {
        var res : number = 0;
        res = this.no1 * this.no2;
        return res;
    }

    Division()
    {
        var res : number = 0;
        res = this.no1 / this.no2;
        return res;
    }

}

var obj1 = new Arithmetic(36,2);
var ret:number = 0;
console.log("Arithmetic operation of 2 numbers:")
ret = obj1.Addition();
console.log("Addition is: "+ret);
ret = obj1.Substraction();
console.log("Substraction is: "+ret);
ret = obj1.Multiplication();
console.log("Multiplication is: "+ret);
ret = obj1.Division();
console.log("Division is: "+ret);


var obj2 = new Arithmetic(20,25);
var ret:number = 0;
console.log("Arithmetic operation of 2 numbers:")
ret = obj2.Addition();
console.log("Addition is: "+ret);
ret = obj2.Substraction();
console.log("Substraction is: "+ret);
ret = obj2.Multiplication();
console.log("Multiplication is: "+ret);
ret = obj2.Division();
console.log("Division is: "+ret);

