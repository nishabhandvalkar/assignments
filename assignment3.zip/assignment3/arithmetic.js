var Arithmetic = /** @class */ (function () {
    function Arithmetic(a, b) {
        this.no1 = a;
        this.no2 = b;
    }
    Arithmetic.prototype.Addition = function () {
        var res = 0;
        res = this.no1 + this.no2;
        return res;
    };
    Arithmetic.prototype.Substraction = function () {
        var res = 0;
        res = this.no1 - this.no2;
        return res;
    };
    Arithmetic.prototype.Multiplication = function () {
        var res = 0;
        res = this.no1 * this.no2;
        return res;
    };
    Arithmetic.prototype.Division = function () {
        var res = 0;
        res = this.no1 / this.no2;
        return res;
    };
    return Arithmetic;
}());
var obj1 = new Arithmetic(36, 2);
var ret = 0;
console.log("Arithmetic operation of 2 numbers:");
ret = obj1.Addition();
console.log("Addition is: " + ret);
ret = obj1.Substraction();
console.log("Substraction is: " + ret);
ret = obj1.Multiplication();
console.log("Multiplication is: " + ret);
ret = obj1.Division();
console.log("Division is: " + ret);
var obj2 = new Arithmetic(20, 25);
var ret = 0;
console.log("Arithmetic operation of 2 numbers:");
ret = obj2.Addition();
console.log("Addition is: " + ret);
ret = obj2.Substraction();
console.log("Substraction is: " + ret);
ret = obj2.Multiplication();
console.log("Multiplication is: " + ret);
ret = obj2.Division();
console.log("Division is: " + ret);
